export class taskmodel{
    ename:string;
    taskname:string;
    constructor(ename:string,taskname:string ){
        this.ename=ename;
        this.taskname=taskname;
    }
}