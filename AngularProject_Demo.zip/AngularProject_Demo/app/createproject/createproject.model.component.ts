export class employeemodel{
    name:string;
    eid:string;
    role:string;
   
    constructor(name:string,eid:string,role:string){
        this.name=name;
        this.eid=eid;
        this.role=role;
       
    }
}