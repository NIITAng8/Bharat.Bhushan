import { CustomdirDirective } from './customdir.directive';

describe('CustomdirDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomdirDirective();
    expect(directive).toBeTruthy();
  });
});
